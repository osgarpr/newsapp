//
//  ArticleService.swift
//  News
//
//  Created by Christopher Ching on 2019-10-01.
//  Copyright © 2019 Christopher Ching. All rights reserved.
//

import Foundation

struct ArticleService {
    
    var totalResults:Int?
    var articles:[Article]?
    
}
