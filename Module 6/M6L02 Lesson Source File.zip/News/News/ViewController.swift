//
//  ViewController.swift
//  News
//
//  Created by Christopher Ching on 2019-10-01.
//  Copyright © 2019 Christopher Ching. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    var model = ArticleModel()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Get the articles from the article model
        model.delegate = self
        model.getArticles()
    }

}

extension ViewController: ArticleModelProtocol {
    
    // MARK: - Article Model Protocol Methods
    
    func articlesRetrieved(_ articles: [Article]) {
        print("articles returned from model")
    }
    
}
