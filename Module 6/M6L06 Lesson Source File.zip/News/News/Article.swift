//
//  Article.swift
//  News
//
//  Created by Christopher Ching on 2019-10-01.
//  Copyright © 2019 Christopher Ching. All rights reserved.
//

import Foundation

struct Article : Decodable {
    
    var author:String?
    var title:String?
    var description:String?
    var url:String?
    var urlToImage:String?
    var publishedAt:String?
    
}
